/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.core.product;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author heerendra.singh
 */
@Path("products")
public class ProductService {
    @GET
    @Path("/info")
    @Produces(MediaType.TEXT_PLAIN)//SCOPE:CLASS LEVEL AND METHOD LEVEL
    public String method()
    {
    return "all copy rights for each product has been reserved";
    }
    @GET
    @Path("/getProduct")
    @Produces(MediaType.APPLICATION_XML)
    public Product getProduct(@MatrixParam("pid") Integer pid,@MatrixParam("pname") String pname)
    {
    Product product = new Product();
    product.setProduct_id(1);
    product.setProduct_name("pid is:"+pid+"product name is"+pname);
    product.setProduct_price(65);
//    if(pid==product.getProduct_id())
        return product;
//    return null;
    }
    @POST
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    @Path("/add")
    public Product addProduct(Product product)
    {
        System.out.println("entered into the service");
        System.out.println(product);
        return product;
    }
    @GET
    @Path("/servicedata/{pid}")
    @Produces(MediaType.TEXT_PLAIN)
    public String serviceData(@PathParam("pid") int pid,@HeaderParam("sessionid") String sessionID,@CookieParam("password") String cookieValue)
    {
        System.out.println("entered in service");
    return "pid is :"+pid+"\nsession id is :"+sessionID+"\ncookie param is :"+cookieValue;
    }
    @GET
    @Path("/user")
    @Produces(MediaType.TEXT_PLAIN)
    public String userdata(@BeanParam User user)
    {
        return "entered userdetails:\nUserID:"+user.getUserid()+"\nUsername:"+user.getUsername()+"\nPassword:"+user.getUserpassword();
    }
}